﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//class Program_7
//{
//    static void Main()
//    {
//        string[] names = { "Smith", "Johnson", "Williams", "Brown", "White", "Orange" };

//        bool allLongerThanThree = names.All(n => n.Length > 3);
//        bool allInRange = names.All(n => n.Length > 3 && n.Length < 10);
//        bool anyStartsWithW = names.Any(n => n.StartsWith("W"));
//        bool anyEndsWithY = names.Any(n => n.EndsWith("Y"));
//        bool containsOrange = names.Contains("Orange");
//        string firstWithSix = names.FirstOrDefault(n => n.Length == 6);
//        string lastLessThanFifteen = names.LastOrDefault(n => n.Length < 15);
//    }
//}











//class Journal
//{
//    public string Title { get; set; }
//    public string Genre { get; set; }
//    public int Pages { get; set; }
//    public DateTime ReleaseDate { get; set; }
//}

//class Program_8
//{
//    static void Main()
//    {
//        var journals = new Journal[]
//        {
//            new Journal { Title = "Politics Today", Genre = "Политика", Pages = 45, ReleaseDate = new DateTime(2022, 5, 10) },
//            new Journal { Title = "Fashion Weekly", Genre = "Мода", Pages = 32, ReleaseDate = new DateTime(2021, 10, 5) },
//            new Journal { Title = "Garden Life", Genre = "Сад и Огород", Pages = 50, ReleaseDate = new DateTime(2020, 3, 15) },
//            new Journal { Title = "Auto World", Genre = "Авто", Pages = 40, ReleaseDate = new DateTime(2023, 8, 20) },
//            new Journal { Title = "Fishing Times", Genre = "Рыбалка", Pages = 25, ReleaseDate = new DateTime(2021, 11, 30) },
//            new Journal { Title = "Hunting Adventures", Genre = "ОХОТА", Pages = 40, ReleaseDate = new DateTime(2022, 6, 25) }
//        };

//        bool allPagesMoreThan30 = journals.All(j => j.Pages > 30);
//        bool allGenresMatch = journals.All(j => j.Genre == "Политика" || j.Genre == "Мода" || j.Genre == "Спорт");
//        bool anyGardenGenre = journals.Any(j => j.Genre == "Сад и Огород");
//        bool anyFishingGenre = journals.Any(j => j.Genre == "Рыбалка");
//        bool containsHunting = journals.Any(j => j.Genre.Equals("Охота", StringComparison.OrdinalIgnoreCase));
//        var first2022 = journals.FirstOrDefault(j => j.ReleaseDate.Year == 2022);
//        var lastAuto = journals.LastOrDefault(j => j.Title.StartsWith("Авто"));

//        Console.WriteLine($"Все журналы имеют больше 30 страниц: {allPagesMoreThan30}");
//        Console.WriteLine($"Все журналы жанра Политика, Мода или Спорт: {allGenresMatch}");
//        Console.WriteLine($"Есть журнал в жанре Сад и Огород: {anyGardenGenre}");
//        Console.WriteLine($"Есть журнал в жанре Рыбалка: {anyFishingGenre}");
//        Console.WriteLine($"Есть журналы по Охоте: {containsHunting}");
//        Console.WriteLine($"Первый журнал 2022 года: {(first2022 != null ? first2022.Title : "Не найден")}");
//        Console.WriteLine($"Последний журнал, название которого начинается с Авто: {(lastAuto != null ? lastAuto.Title : "Не найден")}");
//    }
//}










