﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//class Program_4
//{
//    static void Main()
//    {
//        List<Phone> phones = new List<Phone>
//        {
//            new Phone { Name = "Phone A", Manufacturer = "Company X", Price = 500, ReleaseDate = new DateTime(2018, 5, 10) },
//            new Phone { Name = "Phone B", Manufacturer = "Company Y", Price = 300, ReleaseDate = new DateTime(2020, 7, 20) },
//            new Phone { Name = "Phone C", Manufacturer = "Company X", Price = 700, ReleaseDate = new DateTime(2019, 3, 15) },
//            new Phone { Name = "Phone D", Manufacturer = "Company Z", Price = 100, ReleaseDate = new DateTime(2021, 1, 5) },
//            new Phone { Name = "Phone E", Manufacturer = "Company Y", Price = 450, ReleaseDate = new DateTime(2022, 10, 25) }
//        };

//        Console.WriteLine($"Количество телефонов: {phones.Count()}");
//        Console.WriteLine($"Количество телефонов с ценой больше 100: {phones.Count(p => p.Price > 100)}");
//        Console.WriteLine($"Количество телефонов с ценой в диапазоне от 400 до 700: {phones.Count(p => p.Price >= 400 && p.Price <= 700)}");

//        string manufacturer = "Company X";
//        Console.WriteLine($"Количество телефонов производителя {manufacturer}: {phones.Count(p => p.Manufacturer == manufacturer)}");

//        var minPricePhone = phones.OrderBy(p => p.Price).First();
//        Console.WriteLine($"Телефон с минимальной ценой: {minPricePhone.Name}, Цена: {minPricePhone.Price}");

//        var maxPricePhone = phones.OrderByDescending(p => p.Price).First();
//        Console.WriteLine($"Телефон с максимальной ценой: {maxPricePhone.Name}, Цена: {maxPricePhone.Price}");

//        var oldestPhone = phones.OrderBy(p => p.ReleaseDate).First();
//        Console.WriteLine($"Самый старый телефон: {oldestPhone.Name}, Дата выпуска: {oldestPhone.ReleaseDate.ToShortDateString()}");

//        var newestPhone = phones.OrderByDescending(p => p.ReleaseDate).First();
//        Console.WriteLine($"Самый свежий телефон: {newestPhone.Name}, Дата выпуска: {newestPhone.ReleaseDate.ToShortDateString()}");

//        double averagePrice = phones.Average(p => p.Price);
//        Console.WriteLine($"Средняя цена телефона: {averagePrice}");
//    }
//}

//class Phone
//{
//    public string Name { get; set; }
//    public string Manufacturer { get; set; }
//    public int Price { get; set; }
//    public DateTime ReleaseDate { get; set; }
//}







//class Program_5
//{
//    static void Main()
//    {
//        List<Phone> phones = new List<Phone>
//        {
//            new Phone { Name = "Phone A", Manufacturer = "Company X", Price = 500, ReleaseDate = new DateTime(2018, 5, 10) },
//            new Phone { Name = "Phone B", Manufacturer = "Company Y", Price = 300, ReleaseDate = new DateTime(2020, 7, 20) },
//            new Phone { Name = "Phone C", Manufacturer = "Company X", Price = 700, ReleaseDate = new DateTime(2019, 3, 15) },
//            new Phone { Name = "Phone D", Manufacturer = "Company Z", Price = 100, ReleaseDate = new DateTime(2021, 1, 5) },
//            new Phone { Name = "Phone E", Manufacturer = "Company Y", Price = 450, ReleaseDate = new DateTime(2022, 10, 25) },
//            new Phone { Name = "Phone F", Manufacturer = "Company Z", Price = 250, ReleaseDate = new DateTime(2017, 8, 11) },
//            new Phone { Name = "Phone G", Manufacturer = "Company X", Price = 600, ReleaseDate = new DateTime(2016, 12, 1) }
//        };

//        Console.WriteLine($"Количество телефонов: {phones.Count()}");
//        Console.WriteLine($"Количество телефонов с ценой больше 100: {phones.Count(p => p.Price > 100)}");
//        Console.WriteLine($"Количество телефонов с ценой в диапазоне от 400 до 700: {phones.Count(p => p.Price >= 400 && p.Price <= 700)}");

//        string manufacturer = "Company X";
//        Console.WriteLine($"Количество телефонов производителя {manufacturer}: {phones.Count(p => p.Manufacturer == manufacturer)}");

//        var minPricePhone = phones.OrderBy(p => p.Price).First();
//        Console.WriteLine($"Телефон с минимальной ценой: {minPricePhone.Name}, Цена: {minPricePhone.Price}");

//        var maxPricePhone = phones.OrderByDescending(p => p.Price).First();
//        Console.WriteLine($"Телефон с максимальной ценой: {maxPricePhone.Name}, Цена: {maxPricePhone.Price}");

//        var oldestPhone = phones.OrderBy(p => p.ReleaseDate).First();
//        Console.WriteLine($"Самый старый телефон: {oldestPhone.Name}, Дата выпуска: {oldestPhone.ReleaseDate.ToShortDateString()}");

//        var newestPhone = phones.OrderByDescending(p => p.ReleaseDate).First();
//        Console.WriteLine($"Самый свежий телефон: {newestPhone.Name}, Дата выпуска: {newestPhone.ReleaseDate.ToShortDateString()}");

//        double averagePrice = phones.Average(p => p.Price);
//        Console.WriteLine($"Средняя цена телефона: {averagePrice}");

//        Console.WriteLine("\nПять самых дорогих телефонов:");
//        var top5Expensive = phones.OrderByDescending(p => p.Price).Take(5);
//        PrintPhones(top5Expensive);

//        Console.WriteLine("\nПять самых дешевых телефонов:");
//        var top5Cheap = phones.OrderBy(p => p.Price).Take(5);
//        PrintPhones(top5Cheap);

//        Console.WriteLine("\nТри самых старых телефона:");
//        var top3Oldest = phones.OrderBy(p => p.ReleaseDate).Take(3);
//        PrintPhones(top3Oldest);

//        Console.WriteLine("\nТри самых новых телефона:");
//        var top3Newest = phones.OrderByDescending(p => p.ReleaseDate).Take(3);
//        PrintPhones(top3Newest);
//    }

//    static void PrintPhones(IEnumerable<Phone> phones)
//    {
//        foreach (var phone in phones)
//        {
//            Console.WriteLine($"Название: {phone.Name}, Производитель: {phone.Manufacturer}, Цена: {phone.Price}, Дата выпуска: {phone.ReleaseDate.ToShortDateString()}");
//        }
//    }
//}

//class Phone
//{
//    public string Name { get; set; }
//    public string Manufacturer { get; set; }
//    public int Price { get; set; }
//    public DateTime ReleaseDate { get; set; }
//}
















//class Program_6
//{
//    static void Main()
//    {
//        List<Phone> phones = new List<Phone>
//        {
//            new Phone { Name = "Phone A", Manufacturer = "Company X", Price = 500, ReleaseDate = new DateTime(2018, 5, 10) },
//            new Phone { Name = "Phone B", Manufacturer = "Company Y", Price = 300, ReleaseDate = new DateTime(2020, 7, 20) },
//            new Phone { Name = "Phone C", Manufacturer = "Company X", Price = 700, ReleaseDate = new DateTime(2019, 3, 15) },
//            new Phone { Name = "Phone D", Manufacturer = "Company Z", Price = 100, ReleaseDate = new DateTime(2021, 1, 5) },
//            new Phone { Name = "Phone E", Manufacturer = "Company Y", Price = 450, ReleaseDate = new DateTime(2022, 10, 25) },
//            new Phone { Name = "Phone F", Manufacturer = "Company Z", Price = 250, ReleaseDate = new DateTime(2017, 8, 11) },
//            new Phone { Name = "Phone G", Manufacturer = "Company X", Price = 600, ReleaseDate = new DateTime(2016, 12, 1) },
//            new Phone { Name = "Phone A", Manufacturer = "Company X", Price = 550, ReleaseDate = new DateTime(2019, 6, 10) },
//            new Phone { Name = "Phone B", Manufacturer = "Company Y", Price = 310, ReleaseDate = new DateTime(2020, 7, 25) }
//        };

//        Console.WriteLine("Статистика по количеству телефонов каждого производителя:");
//        var manufacturerStats = phones.GroupBy(p => p.Manufacturer)
//                                      .Select(g => new { Manufacturer = g.Key, Count = g.Count() });
//        foreach (var stat in manufacturerStats)
//        {
//            Console.WriteLine($"{stat.Manufacturer} – {stat.Count}");
//        }

//        Console.WriteLine("\nСтатистика по количеству моделей телефонов:");
//        var modelStats = phones.GroupBy(p => p.Name)
//                               .Select(g => new { Model = g.Key, Count = g.Count() });
//        foreach (var stat in modelStats)
//        {
//            Console.WriteLine($"{stat.Model} – {stat.Count}");
//        }

//        Console.WriteLine("\nСтатистика телефонов по годам:");
//        var yearStats = phones.GroupBy(p => p.ReleaseDate.Year)
//                              .Select(g => new { Year = g.Key, Count = g.Count() });
//        foreach (var stat in yearStats)
//        {
//            Console.WriteLine($"{stat.Year} – {stat.Count}");
//        }
//    }
//}

//class Phone
//{
//    public string Name { get; set; }
//    public string Manufacturer { get; set; }
//    public int Price { get; set; }
//    public DateTime ReleaseDate { get; set; }
//}