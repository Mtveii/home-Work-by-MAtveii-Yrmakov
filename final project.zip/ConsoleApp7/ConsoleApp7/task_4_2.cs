﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//class Program_9
//{
//    static void Main()
//    {
//        int[] arr = { 12, 15, 7, 34, -5, 46, 8, -9 };

//        bool allEven = arr.All(x => x % 2 == 0);
//        bool allInRange = arr.All(x => x > 10 && x < 45);
//        bool anyNegative = arr.Any(x => x < 0);
//        bool anyOddNegative = arr.Any(x => x < 0 && x % 2 != 0);
//        bool containsSeven = arr.Contains(7);
//        int firstOver723 = arr.FirstOrDefault(x => x > 723);
//        int lastNegative = arr.LastOrDefault(x => x < 0);

//        Console.WriteLine($"All even: {allEven}");
//        Console.WriteLine($"All in range: {allInRange}");
//        Console.WriteLine($"Any negative: {anyNegative}");
//        Console.WriteLine($"Any odd negative: {anyOddNegative}");
//        Console.WriteLine($"Contains 7: {containsSeven}");
//        Console.WriteLine($"First > 723: {firstOver723}");
//        Console.WriteLine($"Last negative: {lastNegative}");
//    }
//}











//class Program_10
//{
//    class Book
//    {
//        public string Title { get; set; }
//        public string Author { get; set; }
//        public string Genre { get; set; }
//        public int Pages { get; set; }
//        public int Year { get; set; }
//    }

//    static void Main()
//    {
//        Book[] books = {
//            new Book { Title = "Book1", Author = "Shakespeare", Genre = "Drama", Pages = 120, Year = 1993 },
//            new Book { Title = "Book2", Author = "Byron", Genre = "Poetry", Pages = 80, Year = 2002 },
//            new Book { Title = "Book3", Author = "Author3", Genre = "Horror", Pages = 150, Year = 2000 },
//            new Book { Title = "Book4", Author = "Author4", Genre = "Historical", Pages = 200, Year = 2002 }
//        };

//        bool allPagesOver100 = books.All(b => b.Pages > 100);
//        bool allHistoricalOrSatire = books.All(b => b.Genre == "Historical" || b.Genre == "Satire");
//        bool anyHorror = books.Any(b => b.Genre == "Horror");
//        bool anyShakespeare = books.Any(b => b.Author == "Shakespeare");
//        bool containsByron = books.Any(b => b.Author == "Byron");
//        Book first1993 = books.FirstOrDefault(b => b.Year == 1993);
//        Book last2002 = books.LastOrDefault(b => b.Year == 2002);

//        Console.WriteLine($"All pages > 100: {allPagesOver100}");
//        Console.WriteLine($"All genre Historical or Satire: {allHistoricalOrSatire}");
//        Console.WriteLine($"Any genre Horror: {anyHorror}");
//        Console.WriteLine($"Any author Shakespeare: {anyShakespeare}");
//        Console.WriteLine($"Contains Byron: {containsByron}");
//        Console.WriteLine($"First book in 1993: {(first1993 != null ? first1993.Title : "None")}");
//        Console.WriteLine($"Last book in 2002: {(last2002 != null ? last2002.Title : "None")}");
//    }
//}