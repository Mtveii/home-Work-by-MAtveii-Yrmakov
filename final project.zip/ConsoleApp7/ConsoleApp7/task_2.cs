﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//class Program_1
//{
//    static void Main()
//    {
//        Console.WriteLine("Введите массив целых чисел через пробел:");
//        int[] array = Console.ReadLine().Split().Select(int.Parse).ToArray();

//        Console.WriteLine("Сортировка по возрастанию суммы цифр:");
//        int[] sortedAsc = SortBySum(array, true);
//        PrintArray(sortedAsc);

//        Console.WriteLine("Сортировка по убыванию суммы цифр:");
//        int[] sortedDesc = SortBySum(array, false);
//        PrintArray(sortedDesc);
//    }

//    static int[] SortBySum(int[] array, bool ascending)
//    {
//        return array.OrderBy(x => SumDigits(x) * (ascending ? 1 : -1)).ToArray();
//    }

//    static int SumDigits(int n)
//    {
//        return Math.Abs(n).ToString().Sum(c => c - '0');
//    }

//    static void PrintArray(int[] array)
//    {
//        Console.WriteLine(string.Join(" ", array));
//    }
//}














//class Program_2
//{
//    static void Main()
//    {
//        Console.WriteLine("Введите первый массив стран через запятую:");
//        string[] array1 = Console.ReadLine().Split(',').Select(s => s.Trim()).ToArray();

//        Console.WriteLine("Введите второй массив стран через запятую:");
//        string[] array2 = Console.ReadLine().Split(',').Select(s => s.Trim()).ToArray();

//        Console.WriteLine("Разница первого и второго массива:");
//        var difference = array1.Except(array2);
//        PrintArray(difference);

//        Console.WriteLine("Пересечение массивов:");
//        var intersection = array1.Intersect(array2);
//        PrintArray(intersection);

//        Console.WriteLine("Объединение массивов без дубликатов:");
//        var union = array1.Union(array2);
//        PrintArray(union);

//        Console.WriteLine("Содержимое первого массива без повторений:");
//        var uniqueFirst = array1.Distinct();
//        PrintArray(uniqueFirst);
//    }

//    static void PrintArray(IEnumerable<string> array)
//    {
//        Console.WriteLine(string.Join(", ", array));
//    }
//}









//class Program_3
//{
//    static void Main()
//    {
//        List<Device> devices1 = new List<Device>
//        {
//            new Device { Name = "Phone A", Manufacturer = "Company X", Price = 500 },
//            new Device { Name = "Laptop B", Manufacturer = "Company Y", Price = 1000 },
//            new Device { Name = "Tablet C", Manufacturer = "Company Z", Price = 300 }
//        };

//        List<Device> devices2 = new List<Device>
//        {
//            new Device { Name = "Phone D", Manufacturer = "Company Y", Price = 400 },
//            new Device { Name = "Laptop E", Manufacturer = "Company X", Price = 1200 },
//            new Device { Name = "Tablet F", Manufacturer = "Company W", Price = 350 }
//        };

//        Console.WriteLine("Разница массивов по производителю:");
//        var difference = devices1.Where(d => !devices2.Any(d2 => d2.Manufacturer == d.Manufacturer));
//        PrintDevices(difference);

//        Console.WriteLine("\nПересечение массивов по производителю:");
//        var intersection = devices1.Where(d => devices2.Any(d2 => d2.Manufacturer == d.Manufacturer));
//        PrintDevices(intersection);

//        Console.WriteLine("\nОбъединение массивов без дубликатов производителей:");
//        var union = devices1.Union(devices2, new DeviceManufacturerComparer());
//        PrintDevices(union);
//    }

//    static void PrintDevices(IEnumerable<Device> devices)
//    {
//        foreach (var device in devices)
//        {
//            Console.WriteLine($"Название: {device.Name}, Производитель: {device.Manufacturer}, Стоимость: {device.Price}");
//        }
//    }
//}

//class Device
//{
//    public string Name { get; set; }
//    public string Manufacturer { get; set; }
//    public int Price { get; set; }
//}

//class DeviceManufacturerComparer : IEqualityComparer<Device>
//{
//    public bool Equals(Device d1, Device d2)
//    {
//        return d1.Manufacturer == d2.Manufacturer;
//    }

//    public int GetHashCode(Device d)
//    {
//        return d.Manufacturer.GetHashCode();
//    }
//}