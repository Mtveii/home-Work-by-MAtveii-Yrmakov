﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program_0
{
    static void Main()
    {
        List<Company> companies = new List<Company>
        {
            new Company
            {
                Name = "WhiteFood",
                FoundationDate = DateTime.Now.AddYears(-3),
                BusinessProfile = "Marketing",
                Director = "John White",
                EmployeeCount = 120,
                Address = "London",
                Employees = new List<Employee>
                {
                    new Employee { FullName = "Lionel Smith", Position = "Manager", Phone = "2312345678", Email = "lionel@whitefood.com", Salary = 3000 },
                    new Employee { FullName = "Diana Lee", Position = "Developer", Phone = "2345678901", Email = "di@whitefood.com", Salary = 5000 }
                }
            },
            new Company
            {
                Name = "TechIT",
                FoundationDate = DateTime.Now.AddYears(-5),
                BusinessProfile = "IT",
                Director = "Michael Black",
                EmployeeCount = 250,
                Address = "New York",
                Employees = new List<Employee>
                {
                    new Employee { FullName = "Lionel Brown", Position = "Developer", Phone = "2311111111", Email = "lionel@techit.com", Salary = 4000 },
                    new Employee { FullName = "David White", Position = "Manager", Phone = "2355555555", Email = "david@techit.com", Salary = 3500 }
                }
            },
            new Company
            {
                Name = "FreshFood",
                FoundationDate = DateTime.Now.AddMonths(-4),
                BusinessProfile = "Marketing",
                Director = "Alice Green",
                EmployeeCount = 80,
                Address = "London",
                Employees = new List<Employee>
                {
                    new Employee { FullName = "Alice Black", Position = "Designer", Phone = "2345670000", Email = "alice@freshfood.com", Salary = 2000 },
                    new Employee { FullName = "Diana White", Position = "Manager", Phone = "2312341234", Email = "diwhite@freshfood.com", Salary = 3200 }
                }
            }
        };

        Console.WriteLine("Фирмы с названием, содержащим слово Food:");
        var foodCompanies = companies.Where(c => c.Name.Contains("Food"));
        PrintCompanies(foodCompanies);

        Console.WriteLine("\nФирмы, работающие в области маркетинга:");
        var marketingCompanies = companies.Where(c => c.BusinessProfile == "Marketing");
        PrintCompanies(marketingCompanies);

        Console.WriteLine("\nФирмы, работающие в области маркетинга или IT:");
        var marketingOrITCompanies = companies.Where(c => c.BusinessProfile == "Marketing" || c.BusinessProfile == "IT");
        PrintCompanies(marketingOrITCompanies);

        Console.WriteLine("\nФирмы с количеством сотрудников больше 100:");
        var largeCompanies = companies.Where(c => c.EmployeeCount > 100);
        PrintCompanies(largeCompanies);

        Console.WriteLine("\nФирмы с количеством сотрудников от 100 до 300:");
        var mediumCompanies = companies.Where(c => c.EmployeeCount >= 100 && c.EmployeeCount <= 300);
        PrintCompanies(mediumCompanies);

        Console.WriteLine("\nФирмы, находящиеся в Лондоне:");
        var londonCompanies = companies.Where(c => c.Address == "London");
        PrintCompanies(londonCompanies);

        Console.WriteLine("\nФирмы, у которых фамилия директора White:");
        var whiteDirectorCompanies = companies.Where(c => c.Director.EndsWith("White"));
        PrintCompanies(whiteDirectorCompanies);

        Console.WriteLine("\nФирмы, которые основаны больше двух лет назад:");
        var oldCompanies = companies.Where(c => (DateTime.Now - c.FoundationDate).TotalDays > 365 * 2);
        PrintCompanies(oldCompanies);

        Console.WriteLine("\nФирмы, со дня основания которых прошло 123 дня:");
        var companies123Days = companies.Where(c => (DateTime.Now - c.FoundationDate).TotalDays == 123);
        PrintCompanies(companies123Days);

        Console.WriteLine("\nФирмы, у которых фамилия директора Black и название содержит слово White:");
        var blackDirectorWhiteNameCompanies = companies.Where(c => c.Director.EndsWith("Black") && c.Name.Contains("White"));
        PrintCompanies(blackDirectorWhiteNameCompanies);

        Console.WriteLine("\nСотрудники конкретной фирмы:");
        var companyName = "WhiteFood";
        var employeesOfCompany = companies.FirstOrDefault(c => c.Name == companyName)?.Employees;
        PrintEmployees(employeesOfCompany);

        Console.WriteLine("\nСотрудники с зарплатой больше 3000:");
        var highSalaryEmployees = companies.SelectMany(c => c.Employees).Where(e => e.Salary > 3000);
        PrintEmployees(highSalaryEmployees);

        Console.WriteLine("\nСотрудники с должностью менеджер:");
        var managers = companies.SelectMany(c => c.Employees).Where(e => e.Position == "Manager");
        PrintEmployees(managers);

        Console.WriteLine("\nСотрудники с телефоном, начинающимся на 23:");
        var phone23Employees = companies.SelectMany(c => c.Employees).Where(e => e.Phone.StartsWith("23"));
        PrintEmployees(phone23Employees);

        Console.WriteLine("\nСотрудники с Email, начинающимся на di:");
        var diEmailEmployees = companies.SelectMany(c => c.Employees).Where(e => e.Email.StartsWith("di"));
        PrintEmployees(diEmailEmployees);

        Console.WriteLine("\nСотрудники с именем Lionel:");
        var lionelEmployees = companies.SelectMany(c => c.Employees).Where(e => e.FullName.StartsWith("Lionel"));
        PrintEmployees(lionelEmployees);
    }

    static void PrintCompanies(IEnumerable<Company> companies)
    {
        foreach (var company in companies)
        {
            Console.WriteLine($"Название: {company.Name}, Директор: {company.Director}, Профиль: {company.BusinessProfile}, Сотрудников: {company.EmployeeCount}, Адрес: {company.Address}");
        }
    }

    static void PrintEmployees(IEnumerable<Employee> employees)
    {
        if (employees == null) return;
        foreach (var employee in employees)
        {
            Console.WriteLine($"ФИО: {employee.FullName}, Должность: {employee.Position}, Телефон: {employee.Phone}, Email: {employee.Email}, Зарплата: {employee.Salary}");
        }
    }
}

class Company
{
    public string Name { get; set; }
    public DateTime FoundationDate { get; set; }
    public string BusinessProfile { get; set; }
    public string Director { get; set; }
    public int EmployeeCount { get; set; }
    public string Address { get; set; }
    public List<Employee> Employees { get; set; }
}

class Employee
{
    public string FullName { get; set; }
    public string Position { get; set; }
    public string Phone { get; set; }
    public string Email { get; set; }
    public int Salary { get; set; }
}




