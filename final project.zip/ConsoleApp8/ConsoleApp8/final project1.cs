﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Text.Json;

//class DictionaryApp
//{
//    private Dictionary<string, Dictionary<string, List<string>>> dictionaries;
//    private string filename = "dictionaries.json";

//    public DictionaryApp()
//    {
//        LoadDictionaries();
//    }

//    private void LoadDictionaries()
//    {
//        if (File.Exists(filename))
//        {
//            string json = File.ReadAllText(filename);
//            dictionaries = JsonSerializer.Deserialize<Dictionary<string, Dictionary<string, List<string>>>>(json) ?? new();
//        }
//        else
//        {
//            dictionaries = new();
//        }
//    }

//    private void SaveDictionaries()
//    {
//        string json = JsonSerializer.Serialize(dictionaries, new JsonSerializerOptions { WriteIndented = true });
//        File.WriteAllText(filename, json);
//    }

//    public void CreateDictionary(string name)
//    {
//        if (!dictionaries.ContainsKey(name))
//        {
//            dictionaries[name] = new Dictionary<string, List<string>>();
//            SaveDictionaries();
//            Console.WriteLine($"Словарь '{name}' создан.");
//        }
//        else
//        {
//            Console.WriteLine("Такой словарь уже существует.");
//        }
//    }

//    public void AddWord(string dictionary, string word, string translation)
//    {
//        if (dictionaries.ContainsKey(dictionary))
//        {
//            if (!dictionaries[dictionary].ContainsKey(word))
//            {
//                dictionaries[dictionary][word] = new List<string>();
//            }
//            dictionaries[dictionary][word].Add(translation);
//            SaveDictionaries();
//            Console.WriteLine("Слово добавлено.");
//        }
//        else
//        {
//            Console.WriteLine("Словарь не найден.");
//        }
//    }

//    public void FindTranslation(string dictionary, string word)
//    {
//        if (dictionaries.ContainsKey(dictionary) && dictionaries[dictionary].ContainsKey(word))
//        {
//            Console.WriteLine("Переводы: " + string.Join(", ", dictionaries[dictionary][word]));
//        }
//        else
//        {
//            Console.WriteLine("Перевод не найден.");
//        }
//    }

//    public void DeleteWord(string dictionary, string word)
//    {
//        if (dictionaries.ContainsKey(dictionary) && dictionaries[dictionary].ContainsKey(word))
//        {
//            dictionaries[dictionary].Remove(word);
//            SaveDictionaries();
//            Console.WriteLine("Слово удалено.");
//        }
//        else
//        {
//            Console.WriteLine("Слово не найдено.");
//        }
//    }

//    public void Menu()
//    {
//        while (true)
//        {
//            Console.WriteLine("\nМеню:");
//            Console.WriteLine("1. Создать словарь");
//            Console.WriteLine("2. Добавить слово и перевод");
//            Console.WriteLine("3. Найти перевод");
//            Console.WriteLine("4. Удалить слово");
//            Console.WriteLine("5. Выйти");

//            string choice = Console.ReadLine();
//            switch (choice)
//            {
//                case "1":
//                    Console.Write("Введите название словаря: ");
//                    CreateDictionary(Console.ReadLine());
//                    break;
//                case "2":
//                    Console.Write("Введите название словаря: ");
//                    string dictName = Console.ReadLine();
//                    Console.Write("Введите слово: ");
//                    string word = Console.ReadLine();
//                    Console.Write("Введите перевод: ");
//                    string translation = Console.ReadLine();
//                    AddWord(dictName, word, translation);
//                    break;
//                case "3":
//                    Console.Write("Введите название словаря: ");
//                    dictName = Console.ReadLine();
//                    Console.Write("Введите слово для перевода: ");
//                    word = Console.ReadLine();
//                    FindTranslation(dictName, word);
//                    break;
//                case "4":
//                    Console.Write("Введите название словаря: ");
//                    dictName = Console.ReadLine();
//                    Console.Write("Введите слово для удаления: ");
//                    word = Console.ReadLine();
//                    DeleteWord(dictName, word);
//                    break;
//                case "5":
//                    return;
//                default:
//                    Console.WriteLine("Неверный ввод.");
//                    break;
//            }
//        }
//    }

//    static void Main()
//    {
//        DictionaryApp app = new();
//        app.Menu();
//    }
//}
