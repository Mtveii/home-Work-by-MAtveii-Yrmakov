﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

class QuizApp
{
    private Dictionary<string, User> users;
    private string usersFile = "users.json";

    public QuizApp()
    {
        LoadUsers();
    }

    private void LoadUsers()
    {
        if (File.Exists(usersFile))
        {
            string json = File.ReadAllText(usersFile);
            users = JsonSerializer.Deserialize<Dictionary<string, User>>(json) ?? new();
        }
        else
        {
            users = new();
        }
    }

    private void SaveUsers()
    {
        string json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(usersFile, json);
    }

    public void Register()
    {
        Console.Write("Введите логин: ");
        string username = Console.ReadLine();

        if (users.ContainsKey(username))
        {
            Console.WriteLine("Логин уже существует.");
            return;
        }

        Console.Write("Введите пароль: ");
        string password = Console.ReadLine();
        Console.Write("Введите дату рождения (yyyy-mm-dd): ");
        string birthDate = Console.ReadLine();

        users[username] = new User(username, password, birthDate);
        SaveUsers();
        Console.WriteLine("Регистрация успешна!");
    }

    public bool Login()
    {
        Console.Write("Введите логин: ");
        string username = Console.ReadLine();
        Console.Write("Введите пароль: ");
        string password = Console.ReadLine();

        if (users.ContainsKey(username) && users[username].Password == password)
        {
            Console.WriteLine("Вход выполнен!");
            return true;
        }
        Console.WriteLine("Неверный логин или пароль.");
        return false;
    }

    public void Menu()
    {
        while (true)
        {
            Console.WriteLine("\nМеню:");
            Console.WriteLine("1. Регистрация");
            Console.WriteLine("2. Вход");
            Console.WriteLine("3. Выход");

            string choice = Console.ReadLine();
            switch (choice)
            {
                case "1":
                    Register();
                    break;
                case "2":
                    if (Login())
                    {
                        Console.WriteLine("Добро пожаловать в Викторину!");
                    }
                    break;
                case "3":
                    return;
                default:
                    Console.WriteLine("Неверный ввод.");
                    break;
            }
        }
    }

    static void Main()
    {
        QuizApp app = new();
        app.Menu();
    }
}

class User
{
    public string Username { get; set; }
    public string Password { get; set; }
    public string BirthDate { get; set; }

    public User(string username, string password, string birthDate)
    {
        Username = username;
        Password = password;
        BirthDate = birthDate;
    }
}
